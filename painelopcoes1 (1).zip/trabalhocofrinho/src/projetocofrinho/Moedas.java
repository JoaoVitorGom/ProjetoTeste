package projetocofrinho;

abstract public class Moedas {
	// valor da moeda
	double va;
	// método info
	public abstract void info();
	// método converter
	public abstract double converter();
	
	

}
