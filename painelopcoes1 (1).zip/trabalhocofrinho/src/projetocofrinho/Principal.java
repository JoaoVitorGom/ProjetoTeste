// João Vitor Gomes
// 2571001
package projetocofrinho;

public class Principal {

	public static void main(String[] args) {
    Painelopcoes painelopcoes = new Painelopcoes();
	painelopcoes.mostrarPainel();
    
		
		}

	}


